from tinydb import TinyDB

db = TinyDB('banco2.json')

db.insert({'Nome do animal': 'belle', 'Especie': 'gato', 'Nome do dono': 'Silvia'})