from tinydb import TinyDB

db = TinyDB('banco4.json')

db.insert({'Destino': 'Veneza', 'Preco': 8.500, 'Duracao': 8})