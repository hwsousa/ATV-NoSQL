from tinydb import TinyDB

db = TinyDB('banco3.json')

db.insert({'Tipo de instrumento': 'madeira', 'marca': 'eagle', 'preco': 1.500})