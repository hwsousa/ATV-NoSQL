from tinydb import TinyDB

db = TinyDB('banco1.json')

db.insert({'Titulo': 'cronica francesa','Autor': 'wes anderson','Preco': 12.50})

# db.remove(doc_ids=[6])
